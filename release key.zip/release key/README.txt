Doro Organizer signing key (committed 2026-11-27 by the owner's choice, DEC-109)

debug.keystore is the key that signs every build of Doro Organizer, including
the release app on the owner's phone (version 2.6.0).
Fingerprint (SHA-256): 0E:B6:03:B5:4C:51:9A:E7:C2:37:67:EE:5D:50:C3:5B:96:08:4D:72:29:46:7B:21:26:D2:AF:9F:F1:8A:E6:8A
Type PKCS12, alias androiddebugkey, store and key password "android"
(the standard Android debug-key password).

ON ANOTHER COMPUTER (after cloning or pulling this repository)
1. Rename that computer's own C:\Users\<you>\.android\debug.keystore to
   debug.keystore.old, if it has one (other projects there may use it).
2. Copy "release key\debug.keystore" from this repository to
   C:\Users\<you>\.android\debug.keystore
3. Check it:
   keytool -list -v -keystore %USERPROFILE%\.android\debug.keystore -storepass android
   The SHA256 line must equal the fingerprint above.
4. Build as usual. Every build (debug, release, qa, benchmark) is then signed
   with the key of the phone's app, so it installs as an update and keeps the notes.

KEEP THE REPOSITORY PRIVATE
Anyone who can read this repository can sign an update that the phone installs
over the app, with access to the notes. Never make the repository public and
never add collaborators you would not trust with the notes. If the repository
is ever exposed, switch to a new key (SPEC T27): back up in the app, uninstall,
install a build signed with the new key, restore the backup.
